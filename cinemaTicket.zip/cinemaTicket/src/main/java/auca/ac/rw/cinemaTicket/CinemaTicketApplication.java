package auca.ac.rw.cinemaTicket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinemaTicketApplication.class, args);
	}

}
