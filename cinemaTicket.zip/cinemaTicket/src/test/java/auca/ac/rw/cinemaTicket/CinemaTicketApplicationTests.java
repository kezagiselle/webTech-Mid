package auca.ac.rw.cinemaTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
